
  # Web Dashboard UI Design

  This is a code bundle for Web Dashboard UI Design. The original project is available at https://www.figma.com/design/2HEGIA0atQV7HO3NDE7vYB/Web-Dashboard-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  